<?php
/**
 * SilverTouch Technologies Limited.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://www.silvertouch.com/MagentoExtensions/LICENSE.txt
 *
 * @category   Mt
 * @package    Mt_Multisearch
 * @copyright  Copyright (c) 2011 SilverTouch Technologies Limited. (http://www.silvertouch.com/MagentoExtensions)
 * @license    http://www.silvertouch.com/MagentoExtensions/LICENSE.txt
 */ 
class Mt_Multisearch_Block_Product_Searchproductlist extends Mage_Catalog_Block_Product_List
{
    protected function _beforeToHtml()
    {
	    $toolbar = $this->getToolbarBlock();
		$layer = Mage::getSingleton('catalog/layer');
		$layer->getCurrentCategory()->setIsAnchor(1);
	  //$collection = $layer->getProductCollection();
      //$collection = $this->_getProductCollection();
		$collection = Mage::getModel('catalog/product')->getCollection();	
		$collection->addAttributeToSelect('*');	
		$postData = $this->getRequest()->getParam('searchprod');

		$searchprod = $postData;
		
$findme   = ',';
$pos = strpos($searchprod, $findme);

if ($pos === false) {
		$data = preg_split( "[\r\n]", $searchprod );
		
		 foreach ($data as $key => $value) {
		  if (is_null($value) || $value == "") {
		    unset($data[$key]);
		  }
		} 
} else {
		 $data = explode( ",", $searchprod );		
		 foreach ($data as $key => $value) {
		  if (is_null($value) || $value == "") {
		    unset($data[$key]);
		  }
		} 
}
	
		if(!Mage::getSingleton('core/session')->getAllproducts()) {
			Mage::getSingleton('core/session')->setAllproducts($data);
		}
		$session_data = Mage::getSingleton('core/session')->getAllproducts();
		/*$attributes = Mage::getResourceModel('catalog/product_attribute_collection')
					  ->addFieldToFilter('is_searchable',1)
    				  ->getItems();
		foreach ($attributes as $attribute){
						//echo $attribute->getFrontendLabel();
						echo '<br/>$tmp[] = array(\'attribute\'=>\''.$attribute->getAttributecode().'\',\'like\'=>\'%\'.$value.\'%\');';
					}
		die;*/
		if(count($data) > 0) {
			foreach($data as $key => $value) {
				$value = preg_replace('/[^A-Za-z0-9]/', '', trim($value));
				if(!empty($value) && trim($value)) {
					//$tmp[] = array('attribute'=>'custom_search','like'=>'%'.$value.'%');
					$tmp[] = array('attribute'=>'name','like'=>'%'.$value.'%');
					//$tmp[] = array('attribute'=>'custom_search','like'=>'%'.$value.'%');
					$tmp[] = array('attribute'=>'sku','like'=>'%'.$value.'%');
					/*$tmp[] = array('attribute'=>'name','like'=>'%'.$value.'%');
					$tmp[] = array('attribute'=>'cage','like'=>'%'.$value.'%');
					$tmp[] = array('attribute'=>'code','like'=>'%'.$value.'%');
					$tmp[] = array('attribute'=>'code_name','like'=>'%'.$value.'%');
					$tmp[] = array('attribute'=>'certification','like'=>'%'.$value.'%');
					$tmp[] = array('attribute'=>'cn','like'=>'%'.$value.'%');
					$tmp[] = array('attribute'=>'description','like'=>'%'.$value.'%');
					$tmp[] = array('attribute'=>'lead','like'=>'%'.$value.'%');
					$tmp[] = array('attribute'=>'manufacturer','like'=>'%'.$value.'%');
					$tmp[] = array('attribute'=>'price','like'=>'%'.$value.'%');
					$tmp[] = array('attribute'=>'short_description','like'=>'%'.$value.'%');
					$tmp[] = array('attribute'=>'sku','like'=>'%'.$value.'%');
					$tmp[] = array('attribute'=>'warehouse_location','like'=>'%'.$value.'%');
					$tmp[] = array('attribute'=>'unit_of_measure','like'=>'%'.$value.'%');*/
				} 
			}
		} else if($session_data) {
			foreach($session_data as $key => $value) { 
				$value = strtoupper(preg_replace('/[^A-Za-z0-9]/', '', trim($value)));
				if(!empty($value) && trim($value)) {
					//$tmp[] = array('attribute'=>'custom_search','like'=>'%'.$value.'%');
					//$tmp[] = array('attribute'=>'name','like'=>'%'.$value.'%');
					//$tmp[] = array('attribute'=>'custom_search','like'=>'%'.$value.'%');
					$tmp[] = array('attribute'=>'sku','like'=>'%'.$value.'%');
					/*$tmp[] = array('attribute'=>'name','like'=>'%'.$value.'%');
					$tmp[] = array('attribute'=>'cage','like'=>'%'.$value.'%');
					$tmp[] = array('attribute'=>'code','like'=>'%'.$value.'%');
					$tmp[] = array('attribute'=>'code_name','like'=>'%'.$value.'%');
					$tmp[] = array('attribute'=>'certification','like'=>'%'.$value.'%');
					$tmp[] = array('attribute'=>'cn','like'=>'%'.$value.'%');
					$tmp[] = array('attribute'=>'description','like'=>'%'.$value.'%');
					$tmp[] = array('attribute'=>'lead','like'=>'%'.$value.'%');
					$tmp[] = array('attribute'=>'manufacturer','like'=>'%'.$value.'%');
					$tmp[] = array('attribute'=>'price','like'=>'%'.$value.'%');
					$tmp[] = array('attribute'=>'short_description','like'=>'%'.$value.'%');
					$tmp[] = array('attribute'=>'warehouse_location','like'=>'%'.$value.'%');
					$tmp[] = array('attribute'=>'unit_of_measure','like'=>'%'.$value.'%');*/
				} 
			}
		}
		
		$collection->addFieldToFilter($tmp);
		
		$this->_productCollection = $collection;
		
		if ($orders = $this->getAvailableOrders()) {
            $toolbar->setAvailableOrders($orders);
        }
        if ($sort = $this->getSortBy()) {
            $toolbar->setDefaultOrder($sort);
        }
        if ($dir = $this->getDefaultDirection()) {
            $toolbar->setDefaultDirection($dir);
        }
        if ($modes = $this->getModes()) {
            $toolbar->setModes($modes);
        }

        // set collection to tollbar and apply sort
        $toolbar->setCollection($collection);

        $this->setChild('toolbar', $toolbar);
        Mage::dispatchEvent('catalog_block_product_list_collection', array(
            'collection' => $this->_getProductCollection()
        ));

        $this->_getProductCollection()->load();
        Mage::getModel('review/review')->appendSummary($this->_getProductCollection());
        return parent::_beforeToHtml();
    }
	public function getPostData() {
		$postData = $this->getRequest()->getParam('searchprod');
		$searchprod = $postData;
		
		$findme   = ',';
		$pos = strpos($searchprod, $findme);
		if ($pos === false) {
		$data = preg_split( "[\r\n]", $searchprod );
		
		 foreach ($data as $key => $value) {
		  if (is_null($value) || $value == "") {
		    unset($data[$key]);
		  }
		} 
		} else {
				 $data = explode( ",", $searchprod );		
				 foreach ($data as $key => $value) {
				  if (is_null($value) || $value == "") {
					unset($data[$key]);
				  }
				} 
		}
		
		//return preg_replace('/[^A-Za-z0-9]/', '', trim($data));
		return $data;
    }	
	
	public function getCountofSearch($value) {
	    $value = trim($value); 
		$count = 0;
		$tmp = array();
		//$_productCollection1 = Mage::getModel('catalog/product')->getCollection(); 
						//->addFieldToFilter(array(array('attribute'=>'name','like'=>'%'.$value.'%'))); 
			$layer = Mage::getSingleton('catalog/layer');
			$layer->getCurrentCategory()->setIsAnchor(1);
			$_productCollection1 = Mage::getModel('catalog/product')->getCollection();
		
					//$tmp[] = array('attribute'=>'custom_search','like'=>'%'.$value.'%');
					$tmp[] = array('attribute'=>'sku','like'=>'%'.$value.'%');
					$tmp[] = array('attribute'=>'name','like'=>'%'.$value.'%');
					/*$tmp[] = array('attribute'=>'cage','like'=>'%'.$value.'%');
					$tmp[] = array('attribute'=>'code','like'=>'%'.$value.'%');
					$tmp[] = array('attribute'=>'code_name','like'=>'%'.$value.'%');
					$tmp[] = array('attribute'=>'certification','like'=>'%'.$value.'%');
					$tmp[] = array('attribute'=>'cn','like'=>'%'.$value.'%');
					$tmp[] = array('attribute'=>'description','like'=>'%'.$value.'%');
					$tmp[] = array('attribute'=>'lead','like'=>'%'.$value.'%');
					$tmp[] = array('attribute'=>'manufacturer','like'=>'%'.$value.'%');
					$tmp[] = array('attribute'=>'price','like'=>'%'.$value.'%');
					$tmp[] = array('attribute'=>'short_description','like'=>'%'.$value.'%');
					$tmp[] = array('attribute'=>'warehouse_location','like'=>'%'.$value.'%');
					$tmp[] = array('attribute'=>'unit_of_measure','like'=>'%'.$value.'%');*/
		
		//$_productCollection1 = $_productCollection1->addFieldToFilter(array(array('attribute'=>'name','like'=>'%'.$value.'%')))->addAttributeToFilter(array(array('attribute'=>'visibility','eq'=>4)));
		$_productCollection1 = $_productCollection1->addFieldToFilter($tmp);
		//Mage::getSingleton('catalog/product_status')->addVisibleFilterToCollection($_productCollection1);
		//Mage::getSingleton('catalog/product_visibility')->addVisibleInCatalogFilterToCollection($_productCollection1); 
		//$_productCollection1->addAttributeToFilter('status', 1); 
		
		//echo $_productCollection1->getSelect();
        $data = $_productCollection1->getData();
		
		//$productIds = Mage::getModel('cataloginventory/stock_item')->getCollection()
		//		->addFieldToFilter('is_in_stock', 1)->getAllIds(); 
				
		//$check_id = $data[0]['entity_id'];
		//if(in_array($check_id,$productIds)) {
		//	echo "parul"."<br>";
			$count = count($data);
			
		//} else {
		//	$count = 0;
		//}
	
		return $count;
    }	
	
}
