<?php
/**
 * SilverTouch Technologies Limited.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://www.silvertouch.com/MagentoExtensions/LICENSE.txt
 *
 * @category   Mt
 * @package    Mt_Multisearch
 * @copyright  Copyright (c) 2011 SilverTouch Technologies Limited. (http://www.silvertouch.com/MagentoExtensions)
 * @license    http://www.silvertouch.com/MagentoExtensions/LICENSE.txt
 */ 
class Mt_Multisearch_IndexController extends Mage_Core_Controller_Front_Action
{
    public function showAction()
    {
	    $this->loadLayout();
        $this->renderLayout();
	}
	public function indexAction()
    {
	    $this->loadLayout();
        $this->renderLayout();
	}
}

?>
